<template>
    <h1>Chào mừng đến với Vuejs</h1>
</template>

<style>
    h1{color : red;}
</style>