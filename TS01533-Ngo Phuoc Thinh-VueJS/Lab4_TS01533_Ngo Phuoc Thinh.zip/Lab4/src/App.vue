<script setup>
import Hello from './components/Hello.vue';
import bai3 from './components/bai3.vue';
import bai4 from './components/bai4.vue';
</script>

<template>
  <bai4 />
</template>

<style scoped>
</style>
